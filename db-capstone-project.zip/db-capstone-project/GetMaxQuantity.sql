DELIMITER //
CREATE PROCEDURE GetMaxQuatity ()
BEGIN
SELECT MAX(Quatity) as `Max Quatity in Order` FROM Orders;
END //

DELIMITER ;
