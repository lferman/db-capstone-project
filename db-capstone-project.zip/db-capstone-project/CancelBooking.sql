CREATE DEFINER=`lferman`@`localhost` PROCEDURE `CancelBooking`(IN bookingID INT)
BEGIN
DELETE FROM Bookings
WHERE BookingID = bookingID;
SELECT CONCAT('Booking ', bookingID, ' cancelled') as `Confirmation`;
END