CREATE DEFINER=`lferman`@`localhost` PROCEDURE `UpdateBooking`(IN bookingID INT, IN bookingDATE DATE)
BEGIN
UPDATE Bookings
SET BookingDate = bookingDATE
WHERE BookingID = bookingID;
SELECT CONCAT('Booking ', bookingID, ' updated') as `Confirmation`;
END