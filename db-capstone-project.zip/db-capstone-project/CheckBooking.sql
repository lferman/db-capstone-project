CREATE DEFINER=`lferman`@`localhost` PROCEDURE `CheckBooking`(IN bookingDate DATE, IN tableNUM INT)
BEGIN
SELECT CONCAT('Table ',TableNumber,' is already booked') as `Booking status` FROM Bookings WHERE BookingDate = bookingDate AND TableNumber = tableNUM;
END