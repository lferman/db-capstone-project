CREATE DEFINER=`lferman`@`localhost` PROCEDURE `AddValidBooking`(IN bookingDATE DATE, IN tableNUM INT)
BEGIN
    IF EXISTS (SELECT 1 FROM Bookings WHERE BookingDate = bookingDATE AND TableNumber = tableNUM) THEN
        SELECT CONCAT('Table ', TableNumber, ' is already booked - booking cancelled') AS `Booking status`;
    ELSE
        INSERT INTO Bookings(BookingDate, TableNumber) VALUES(bookingDATE, tableNUM);
        SELECT CONCAT('Table ', TableNumber, ' booked successfully on ', bookingDATE) AS `Booking status`;
    END IF;
END