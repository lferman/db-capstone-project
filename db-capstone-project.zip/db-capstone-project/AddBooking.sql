CREATE PROCEDURE `AddBooking` (IN bookingID INT, IN customerID INT, IN bookingDATE DATE, IN tableNUM INT)
BEGIN
INSERT INTO Bookings(BookingID, BookingDate, TableNumber, CustomerID) VALUES (bookingID, bookingDATE, tableNUM, customerID);
SELECT 'New booking Added' as `Confirmation`;
END
